package com.mamburuapps.coderswag.model

class Product(val title:String, val price: String, val image: String)